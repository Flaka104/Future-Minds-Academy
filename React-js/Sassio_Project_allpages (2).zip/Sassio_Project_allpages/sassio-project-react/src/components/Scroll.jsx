export default function Scroll(){
    return(
<div>
<div className="scroll-to-top">
         <a href="index.html#top"><span className="material-symbols-outlined arrow-upward">arrow_upward</span></a>
      </div>
</div>
    );
}